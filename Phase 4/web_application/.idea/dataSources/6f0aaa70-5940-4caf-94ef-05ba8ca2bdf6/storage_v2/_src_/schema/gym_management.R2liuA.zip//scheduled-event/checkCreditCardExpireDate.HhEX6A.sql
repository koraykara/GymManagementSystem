create definer = root@localhost event checkCreditCardExpireDate on schedule
    every '1' DAY
        starts '2020-02-02 00:00:00'
    enable
    do
    BEGIN
        UPDATE system_user, customer
        SET system_user.EndDate = CURRENT_TIMESTAMP
		WHERE system_user.UsernameID = customer.UsernameID and customer.CreditCardExpireDate <= CURRENT_DATE;
    END;

