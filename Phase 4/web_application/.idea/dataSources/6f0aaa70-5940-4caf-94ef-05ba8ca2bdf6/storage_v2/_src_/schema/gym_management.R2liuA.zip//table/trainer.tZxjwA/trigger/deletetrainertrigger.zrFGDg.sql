create definer = root@localhost trigger deleteTrainerTrigger
    after delete
    on trainer
    for each row
begin
			delete from system_user where system_user.UsernameID = old.UsernameID;
		end;

