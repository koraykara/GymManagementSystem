create definer = root@localhost trigger insertTrainerTrigger
    before ınsert on trainer
	for each row
begin
		   insert into system_user(UsernameID) values (new.UsernameID);
	   end;

