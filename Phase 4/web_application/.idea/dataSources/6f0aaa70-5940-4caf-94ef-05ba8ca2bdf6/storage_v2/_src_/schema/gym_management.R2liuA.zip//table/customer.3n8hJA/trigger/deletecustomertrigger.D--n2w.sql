create definer = root@localhost trigger deleteCustomerTrigger
    after delete
    on customer
    for each row
begin
			delete from system_user where system_user.UsernameID = old.UsernameID;
		end;

