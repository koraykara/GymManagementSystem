create definer = root@localhost trigger insertCustomerTrigger
    before ınsert on customer
	for each row
begin
		   insert into system_user(UsernameID) values (new.UsernameID);
	   end;

